// ==UserScript==
// @name         novelfull things
// @namespace    http://tampermonkey.net/
// @version      0.1.2
// @description  try to take over the world!
// @author       You
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// @match        https://readlightnovels.net/*
// @match        https://readnovelfull.com/*
// @match        https://novelfull.com/*
// @match        https://novelonlinefull.com/*
// @match        https://fastnovel.net/*
// @match        https://www.scribblehub.com/*
// @grant        none
// ==/UserScript==

function concatAll(strs){
   var sOut = "";
   for (let i = 0; i<strs.length; i++){
       sOut = sOut.concat(strs[i]);
   };
   return sOut
}

function isDot(strs){
    return strs == "."
}

function getAllIndexes(arr, val) {
    var indexes = [], i = -1;
    while ((i = arr.indexOf(val, i)) != -1){
        indexes.push(i);
    }
    return indexes;
}
function getDocHeight() {
    var D = document;
    return Math.max(
        D.body.scrollHeight, D.documentElement.scrollHeight,
        D.body.offsetHeight, D.documentElement.offsetHeight,
        D.body.clientHeight, D.documentElement.clientHeight
    );
}

(function() {
    var hr_l = document.getElementsByTagName("hr");
    for (let h = hr_l.length-1;h>=0;h--){
        hr_l[h].remove()
    }

    var cont = document.getElementsByTagName("p");

    for (let i = 0 ; i < cont.length-1; i++){

        var str = cont[i].innerHTML
        let str_o = str.replace(/\s\./g,".")
        //console.log(str_o)
        cont[i].innerHTML = str_o

        var line = Array.from(cont[i].innerHTML);
        if (line.length == 0) continue //empty <p></p>


        var f = 0;
        if (cont[i].innerHTML[0] === " "){f = 1;} //<p> starts with 1 space

        if (cont[i].innerHTML.includes("______")){
            cont[i].innerHTML = "...o..."
            console.log("underscore line")
        }

        //broken paragraph
        if (cont[i].innerHTML.charCodeAt(f)<123 & cont[i].innerHTML.charCodeAt(f)>96){
            var nline = line.concat(Array.from(cont[i].innerHTML));
            cont[i-1].innerHTML = concatAll(nline);
            cont[i].remove();
            i = i-1;
            console.log(concatAll(nline));
            
        }



        let indexes = getAllIndexes(line,".");



        if (indexes.length >= 2) {
            //console.log(indexes);
            var plusmin2_inexes = indexes.map(function (num, idx) {return num+2 == indexes[idx+1]||num-2 == indexes[idx-1];}) //ugly but it is what it is
            //console.log(plusmin2_inexes);
            for (let j = indexes.length-1; j>=0 ; j--){
                if (plusmin2_inexes[j]){
                    line.splice(indexes[j],1);

                };
                if (cont[i].innerHTML.charCodeAt(j) == " "){
                    console.log(cont[i].innerHTML)
                };
            };
            cont[i].innerHTML = concatAll(line);
        };

    }

    var ads = Array.from(document.getElementsByClassName("ads"));
    while (ads.length>0 ){
        ads.pop().remove();
    }

    // so far all that have "If you find...." have it at chapter content
    try{
    var cls_thng = document.getElementById("chapter-content").children
    //console.log('aha');
    //console.log(cls_thng);
    for (let i = cls_thng.length-1; i>=cls_thng.length-10; i--){
        let stng = "If you find any errors ( broken links, non-standard content, etc";
        //console.log(cls_thng[i],'1');
        if (cls_thng[i].innerHTML.includes(stng)){
            //console.log(cls_thng[i],'2');
            cls_thng[i].remove();
            break
        }
    }}
    catch{}

    /*
    //var bton0 = document.createElement("a")
    var bton1 = document.createElement("a");
    var bton_group = document.getElementsByClassName("btn-group");
    //console.log(bton_group,typeof(bton_group));
    //bton0.innerHTML = '<a class="btn btn-success" id="Don\'t Read">Stop Auto-Read</a>';
    bton1.innerHTML = '<a class="btn btn-success" id="Don\'t Next">Stop Auto-Next</a>';

    //bton_group[0].appendChild(bton0);
    bton_group[1].appendChild(bton1);

    //var pagedDown = false
    bton1.addEventListener("click", dontNext, false);
    var nxit = true
    var go_next

    function dontNext(){
        console.log("did the thing to stop the other thing");
        nxit = false;
        clearTimeout(go_next);
    }

    function next_it(){
        if (nxit){
            console.log("Going next")
            go_next = setTimeout(function() {document.getElementById("next_chap").click()},10);
        }else{
            console.log("Going next... not")
        }
    }

    var chechPrev_chap = window.setInterval( function(){
        var t
        try{
        t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
        }//console.log(t)
        catch{}
        if ( t == "Prev Chapter") {
            console.log("ch. end")
            next_it()
            clearInterval(chechPrev_chap)
        }
    },250)

    //$(window).scroll(function() {
      //  console.log($(window).scrollTop())
        //if($(window).scrollTop() + $(window).height() > getDocHeight() - 50) {
          //  //$(window).unbind('scroll')
            //pagedDown = true
        //}

        //var txt = document.getElementsByClassName("msreadout-line-highlight")
        //console.log(txt)

        //document.getElementsByClassName("msreadout-line-highlight")[0].addEventListener("change",next_it);
        //var txt = document.getElementsByClassName("msreadout-line-highlight")

        //console.log(txt.innerText,typeof(txt))
        //var go_next = setTimeout(nextChap,2500);
        //var dontNext = function(){clearTimeout(go_next)}
        //bton1.addEventListener("click", dontNext, false);
    //});
    */


    })();








