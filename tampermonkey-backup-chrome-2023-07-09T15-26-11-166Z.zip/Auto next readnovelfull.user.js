// ==UserScript==
// @name         Auto next readnovelfull
// @namespace    http://tampermonkey.net/
// @version      0.2.0
// @description  Auto next novel chapter when reading aloud on ms edge
// @author       Aettos
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// @require      https://raw.githubusercontent.com/JP235/TM_helper_functions_for_scripts/master/auto_next_.js
// @match        https://readnovelfull.com/*
// @match        https://allnovelfull.com/*
// @match        https://readnovelfull.me/*
// @match        https://novelusb.com/*
// @match        https://novelfull.com/*
// @match        https://freewebnovel.com/*
// @match        https://fastnovel.net/*
// @match        https://allnovelfull.com/*
// @match        https://readlightnovels.net/*
// @grant        none
// ==/UserScript==
/* globals jQuery, $,
getDocHeight,
delAll,
dealWithNoReader,
makeButton,
ssplay,
sspause,
changeSpanText,
*/

(function() {
    'use strict';
    delAll("hr")

    var chap_nav
    var bton_group
    try{
        chap_nav = document.getElementsByClassName("chapter-nav");
        bton_group = chap_nav[0].firstChild
    }catch{
        chap_nav = document.getElementsByClassName("chr-nav");
        bton_group = chap_nav[0].firstElementChild
    }

    const bton0 = makeButton()

    var nxt_button0 = bton_group.lastElementChild; //for the smooth edges on first and last elements of the btn-group
    bton_group.replaceChild(bton0,nxt_button0);
    bton_group.appendChild(nxt_button0);

    //try{
    for (let elm of chap_nav){
        let fc = elm.firstElementChild;
        elm.replaceChild(bton_group.cloneNode(true),fc)
        elm.firstElementChild.children[2].onclick = toggleAutoNext
    }
    //}
    //catch{}

    var nxit = true
    let c = document.getElementsByClassName("col-xs-12")[0]
    for (let i = 0; i<5; i++){
        c.children[0].remove()}

    function toggleAutoNext(){
        let buttons = Array.from(chap_nav).map(c => c.firstElementChild.children[2])
        if (nxit){
            console.log("did the thing to stop the other thing");
            changeSpanText(buttons,nxit)
            nxit = false;
        }else{
            console.log("did the thing to do the other thing");
            changeSpanText(buttons,nxit)
            nxit = true;
        }
    }

    // function chech_msreader(){
    const next = document.getElementById("next_chap")
    var chechPrev_Chapter = window.setInterval(() => {
        try{
            let highlightedtext = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
            if (
                highlightedtext == "Prev Chapter" ||
                highlightedtext == "Next Chapter"
            ){
                next.click()
                clearInterval(chechPrev_Chapter)
            }
        }
        catch{}

    },30)
    // }
    // chech_msreader()
    //     $(window).scroll(function() {
    //         //console.log($(window).scrollTop() , $(window).height() , getDocHeight()*0.8) // I could get the height of the buttons but this works well sooo...
    //         if($(window).scrollTop() + $(window).height() > getDocHeight()*0.2) {
    //             $(window).unbind('scroll')
    //             chech_msreader()

    //         }})


    })();