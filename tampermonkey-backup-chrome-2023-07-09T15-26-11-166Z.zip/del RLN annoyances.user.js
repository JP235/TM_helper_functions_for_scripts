// ==UserScript==
// @name         del RLN annoyances
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.readlightnovel.me/*
// @grant        none
// ==/UserScript==


function del_all(na){
    var i;
    var all_na = document.getElementsByTagName(na);
    var l = all_na.length;
    for ( i = 0; i < l; i++ ) {
        if (all_na[0] === undefined){continue};
        all_na[0].remove();
        };
}
function noDivNoEmptyBrYesP(thing){
    switch(thing.tagName){
        case "p":
            console.log(thing.innerHTML);
            break;
        case "DIV":
            console.log(thing);
            thing.remove()
            break;
        case "BR":
            if (thing.innerHTML == "" | thing.innerText == ""){
                //thing.remove()
            }
    }
}
(function() {
    'use strict';

    var bad_thing = document.body.children[3];

    //console.log(bad_thing);
    //console.log(typeof(bad_thing));

    bad_thing.remove()
    //body.children[3] == style
    //style.chapter-content3.... npi de como acceder a el valor, ergo npi de como eliminarlo


    del_all("center");
    del_all("small");
    del_all("hr");


    function removeAllNotP(){
        var des = document.getElementsByClassName("desc")[0].children;
        console.log(des)
        for (var n = des.length; n>0;n--){
            try{
                noDivNoEmptyBrYesP(des[n])
            }

            catch(err){console.log("Error!!",err.message)}
        }
        console.log(des)}

    removeAllNotP()

    var j;
    var all_par = document.getElementsByTagName("p");

    function removeNameOfSpeaker(par){
        let lcp = par.innerHTML.lastIndexOf(")")
        if (lcp == par.innerHTML.length-1){
            let lop = par.innerHTML.lastIndexOf("(")
            if (par.innerHTML.substring(lop, lcp).indexOf(" ") == -1){
                let name = par.innerHTML.slice(lop, lcp+1)
                let new_txt = par.innerHTML.replace(name, "")
                par.innerHTML = new_txt
            }
        }
    }

    for ( j = 0; j < all_par.length; j++ ) {

        if (all_par[j].innerHTML == "Advertisement" ){
            all_par[j].remove();
        }
        if (all_par[j].innerHTML == " " || all_par[j].innerHTML == "" || all_par[j].innerHTML == "&nbsp;"){
            all_par[j].remove();
            //only works because there are never 2 "&nbsp;" in a row
        }
        removeNameOfSpeaker(all_par[j])
        do {
            var str1 = all_par[j].innerHTML;
            var res1 = str1.replace("&nbsp;", "");
            all_par[j].innerHTML = res1;
            //console.log("dunit");
           }
        while (all_par[j].innerHTML.includes("&nbsp;"));

        let ntx = all_par[j].innerHTML.replace(/\u002E/g, ". ");
        all_par[j].innerHTML = ntx

        do {
            var str = all_par[j].innerHTML;
            var res = str.replace(" .", ".");
            all_par[j].innerHTML = res;
            //console.log("dunit");
           }
        while (all_par[j].innerHTML.includes(" ."));
    }

    var nxit = true
    const ltrsGo = "Visit the translator’s website"
    function next_it(){
        console.log(nxit)
        if (nxit){
            //console.log("Going next")
            document.getElementsByClassName("next next-link")[0].click();
            //clearInterval(chechPrev_Chapter)
        }else{
            //console.log("Going next... not")
        }
    }
    function chech_msreader(){
        var chechPrev_Chapter = window.setInterval( function(){
            var t
            try{
                t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
                //console.log(t)
            }//
            catch{}
            if ( t == ltrsGo) {
                next_it()
            }
        },50)
        }
    chech_msreader()

})();















