// ==UserScript==
// @name         Overflow
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match      *
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    window.addEventListener('load', function() {
        setTimeout(() => {
            console.log("auto overflow")
            var a = document.getElementsByTagName("html")
            a[0].style = "auto"
            a = document.getElementsByTagName("body")
            a[0].style = "auto"
        },2000)
    }, false)


})();