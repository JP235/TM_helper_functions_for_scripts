// ==UserScript==
// @name         regex 'auto next'
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://readnovelfull.com/*
// @match        https://allnovelfull.com/*
// @match        https://novelfull.com/*
// @match        https://novelusb.com/*
// @match        https://freewebnovel.com/*
// @match        https://readnovelfull.me/*
// @match        https://isekailunatic.com/*
// @require      file://C:\\Users\\jpman\\Documents\\Code\\TM_scripts\\patterns.user.js
// @require      file://C:\\Users\\jpman\\Documents\\Code\\TM_scripts\\auto_next_.js
// @grant        none
// ==/UserScript==
/* globals jQuery, $,
REPL,
getDocHeight,
delAll,
dealWithNoReader,
makeButton,
ssplay,
sspause,
changeSpanText,
wordPlusLower,
hasReadableLetters
*/

function getTalker(str) {
    let pattern = /\([a-zA-Z\-]*\) */;
    let match = str.match(pattern);
    if (match) {
        // console.log("match",match)
        return match[0]
    }
}

function logDiffStrs(a, b) {
    var maxLength = Math.max(a.length, b.length);
    var diff = []
    var diff1 = []

    for (var i = 0; i < maxLength; i++) {
        if (a[i] !== b[i]) {
            diff.push(a[i])
            diff1.push(b[i])
            // console.log("Difference at position", i, ":", a[i], "->", b[i]);
        }
    }
    return [diff.join(""),diff1.join("")]
}

var state = true

function toggleRemovedLines() {
    let elements = document.getElementsByClassName("removedLine");
    let elements2 = document.getElementsByClassName("changed-line");
    Array.from(elements).forEach(e => {
        e.style.display = state ? "none": "inline-block !important"
    })
    Array.from(elements2).forEach(e => {
        e.setAttribute("class", state ? "changed-line": "show changed-line")
    })
    state = !state

}
var style = document.createElement("style");

// eslint-disable-next-line no-multi-str
style.innerHTML = '\
.changed-line.show{\
}\
.show.changed-line::after { \
content: attr(data) "\\A";\
color: rgb(51, 125, 255) ;\
} \
.removedLine {display: none;} \
.toggleRemovedLines { background: transparent; color:transparent } \
.toggleRemovedLines:hover { background: black; }';

document.head.appendChild(style);
let lastchildChapCont
let content
try {
    content = document.getElementsByClassName("chapter container")[0]
    lastchildChapCont = document.getElementById("chapter-content").lastChild
}catch {
    try {
        content = document.getElementsByClassName("chr-c")[0]
        lastchildChapCont = document.getElementById("chr-content").lastChild
    }catch {
        content = document.getElementsByClassName("site-content")[0]
        lastchildChapCont = document.getElementById("content").lastChild
    }
}
const ps = content.querySelectorAll('p,li,b,h1')

var bton0 = document.createElement("button");

bton0.setAttribute("class", "toggleRemovedLines");
bton0.style.width = "45px";
bton0.style.height = "45px";
bton0.style.marginRight = "5px";
bton0.style.position = "fixed"
bton0.style.top = "10px"
bton0.style.right = "10px"
bton0.style.border = "transparent"
bton0.type = "button"
bton0.title = "toggle mod lines"

bton0.onclick = toggleRemovedLines
content.appendChild(bton0);

(function() {
    'use strict';

    function regexDealWith(v) {
        // console.log("regex")
        let text = v.innerText

        for (let p of patternsRegex) {
            text = text.replaceAll(p[0], p[1]);
            text = text.replaceAll(p[0], p[1]); //Ka ka ka! > Kah kah ka! > Kah kah kah!
        }
        if (v.innerText != text) {
            const talker = getTalker(v.innerText)
            // console.log(talker)
            v.setAttribute("data", talker ?? "");
            v.setAttribute("class", "changed-line show");
            // console.log("diff",logDiffStrs(v.innerText,text))
        }
        return text
    }
    function removeLines(v) {
        // console.log(text)
        for (let p of patternsStarts) {
            // removeIncludes(v,p)
            if (v.innerText.startsWith(p)){
                console.log("startsWith",p,"\n",v.innerText)
                // v.style = "display:none";
                v.className = "removedLine"
                return true}
        }
        for (let p of patternsIncludes) {
            // removeIncludes(v,p)
            if (v.innerText.includes(p)){
                console.log("includes:",p,"\n",v.innerText)
                // v.style = "display:none";
                v.className = "removedLine"
                return true}
        }
        return false
    }

    function dealWithNoReader(ps) {

        console.log("----------------");
        // console.log("");
        console.log("dealWithNoReader");
        const arrPs = Array.from(ps)
        arrPs.push(lastchildChapCont)
        for (let [i,v] of arrPs.entries()) {
            try {
                if (v.querySelector("a")) {
                    // console.log("innerText")
                    // console.log(v.innerText)
                    continue
                }
            }catch (error){
                // console.log(error)
                // console.log(v)
            }
            if (!v.innerText || ["", " "].includes(v.innerText)) continue;
            // console.log(i)
            v.innerText = regexDealWith(v) // much much much faster than modifying v inside the function
            if (removeLines(v)) continue

            if (!hasReadableLetters(v.innerText)) {
                // console.log(v, v.innerText);
                v.setAttribute("data", "\u00A0\u00A0"+ v.innerText);
                v.setAttribute("class", "changed-line show");
                v.innerText = REPL;
                // console.log(v.innerText);
            }

            if (/[a-z]| /.test(v.innerText.charAt(0)) &&
                (/([a-z0-9]| [^\.])/.test(arrPs[i-1].innerText.slice(-1)))) {
                console.log(arrPs[i-1].innerText.slice(-20,))
                console.log(v.innerText);
                arrPs[i-1].innerText = arrPs[i-1].innerText + " " + v.innerText
                v.innerText = ""
            }
        }
        // console.log("");
        console.log("----------------");

    }
    dealWithNoReader(ps)
    delAll("br")
})();