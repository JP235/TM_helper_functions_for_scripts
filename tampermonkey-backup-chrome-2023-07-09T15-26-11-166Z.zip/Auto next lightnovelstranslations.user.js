// ==UserScript==
// @name         Auto next lightnovelstranslations
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://lightnovelstranslations.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=lightnovelstranslations.com
// @grant        none
// ==/UserScript==

function hasReadableLetters(text){
    let minusc = [97,122]
    let mayusc = [65,90]
    for (let l =0;l< text.length;l++){
        let cc = text.charCodeAt(l)
        if (cc > mayusc[0] && cc < mayusc[1] || cc > minusc[0] && cc < minusc[1] || cc==42){
            return true
        }
    }
    return false
}

function dealWithNoReader(){
    let ps = document.getElementsByTagName("p")
    for (let v of ps){
        let e = v.innerText
        if (hasReadableLetters(e)){
            continue
        }else{
        console.log(v.innerText)
        v.innerText = "[.]"
        console.log(v.innerText)
        }

    }}


function autonext(text,ref){
    var chechPrev_Chapter = window.setInterval(function(){
        var t
        try{
            t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
            //console.log(t)
            if ( t.includes(text)) {
                //console.log("ch. end")
                setTimeout(function() {window.location.replace(ref)},1);
            }
        }//
        catch{}

    },100)}

(function() {
    'use strict';
    dealWithNoReader()
    const b = document.getElementsByClassName("alignright")[0].children[0].href
    autonext("Overlimit Skill Holder Vol ",b)
})();