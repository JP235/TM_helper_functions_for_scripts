// ==UserScript==
// @name         auto next death mage
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://lightnovelbastion.com/*
// @icon         https://www.google.com/s2/favicons?domain=lightnovelbastion.com
// @grant        none
// ==/UserScript==

function del_all(na){
    var all_na = document.getElementsByTagName(na);
    var l = all_na.length;
    for ( var i = 0; i < l; i++ ) {
        if (all_na[0] === undefined){
            continue
        };
        //
        all_na[0].remove();
    };
}
(function() {
    'use strict';

    const theirEndphrase = "Want to support Yoshi's translations? Head over to the Donations Page"
    const myEndphrase = "End of chapter, Going next!"

    var yoshi = document.getElementsByClassName('lnbad-tag lnbad-tag-11')[0].children;
    //console.log(yoshi)
    for (var i = 0; i <yoshi.length; i++ ) {
        if (yoshi[i].innerHTML == theirEndphrase){
        yoshi[i].innerHTML = myEndphrase;
            break
        };
    }



    del_all("blockquote")

    var nxit = true
    function next_it(){
        console.log(nxit)
        if (nxit){
            console.log("Going next")
            setTimeout(function() {document.getElementsByClassName("btn next_page")[0].click()},750);
            //clearInterval(chechPrev_Chapter)
        }else{
            console.log("Going next... not")
        }
    }
    function chech_msreader(){
        var chechYoshi = window.setInterval( function(){
            var t
            try{
                t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
                //console.log(t)
            }//
            catch{}
            if ( t == myEndphrase) {
                //console.log("ch. end")
                next_it()
            }
        },100)
        }
    chech_msreader()



})();