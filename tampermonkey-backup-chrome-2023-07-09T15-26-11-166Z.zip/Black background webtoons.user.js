// ==UserScript==
// @name         Black background webtoons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.webtoons.com/en/fantasy/tower-of-god/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var content = document.getElementById("content")
    content.style.background = "rgb(0,0,0)"
    var bottomEpisodeList = document.getElementById("bottomEpisodeList")
    bottomEpisodeList.style.background = "rgb(0,0,0)"
    var cbox_module = document.getElementById("cbox_module")
    cbox_module.style.backgroundColor = "rgb(0,0,0)"


    // Your code here...
})();