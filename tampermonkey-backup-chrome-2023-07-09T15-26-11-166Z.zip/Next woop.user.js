// ==UserScript==
// @name         Next woop
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://woopread.com/*
// @icon         https://www.google.com/s2/favicons?domain=woopread.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var nxit = true

    function next_it(){
        console.log(nxit)
        if (nxit){
            console.log("Going next")
            setTimeout(function() {document.getElementsByClassName("btn next_page")[0].children[0].click()},100);
            //clearInterval(chechPrev_Chapter)
        }else{
            console.log("Going next... not")
        }
    }
    function chech_msreader(){
        var chechPrev_Chapter = window.setInterval( function(){
            var t
            try{
                t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
                //console.log(t)
            }//
            catch{}
            if ( t.includes("For any errors and issues contact me through discord")) {
                console.log("ch. end")
                next_it()
            }
        },50)
        }
    chech_msreader()



})();