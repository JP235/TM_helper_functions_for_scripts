// ==UserScript==
// @name         text/js del
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://watchmonkonline.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('readystatechange', event => {

        // When window loaded ( external resources are loaded too- `css`,`src`, etc...)
        if (event.target.readyState === "complete") {
            console.log("hi");
            //alert("hi");
            var txjs = document.getElementsByTagName('script');
            console.log(txjs);
            for (var i = txjs.length ; i>= 0 ; i--){
                var txjs_i = txjs[i];
                try{
                    if (txjs_i.getAttribute("type") == 'text/javascript'){
                        console.log("deleted");
                        console.log(txjs[i]);
                        txjs[i].remove();
                        console.log("end");
                    }
                }
                catch {
                    console.log("err")
                    continue
            }

            }
        }
    });


})();