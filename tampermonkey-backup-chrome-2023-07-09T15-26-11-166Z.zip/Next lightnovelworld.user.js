// ==UserScript==
// @name         Next lightnovelworld
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.lightnovelworld.com/*
// @match        https://www.lightnovelpub.com/*
// @match        https://www.webnovelpub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=lightnovelworld.com
// @grant        none
// ==/UserScript==

function delAll(na){
    var all_na = document.getElementsByTagName(na);
    for ( let i = all_na.length-1; i > -1 ; i-- ) {
        if (all_na[i] === undefined){continue};
        all_na[i].remove();
        };
}

function hasReadableLetters(text){
    const minusc = [97,122]
    const mayusc = [65,90]
    const numbers = [48,57]
    const chars = [42, //*
                   61, //=
                   //63, //?
                   126 //~
                  ]
    if (text == "[.]"){return true}
    for (let l =0;l< text.length;l++){
        let cc = text.charCodeAt(l)
        if (cc > mayusc[0] && cc < mayusc[1] ||
            cc > minusc[0] && cc < minusc[1] ||
            cc > numbers[0] && cc < numbers[1]
            //|| chars.includes(cc)
           ){
            return true
        }
    }
    return false
}

const wordPlusLower = (m) => {
    return [m.substring(0,m.length-2),m[m.length-1].toLowerCase()].join('')}

function regexDealWith(text,patterns){
    for (let p of patterns){
        text = text.replaceAll(p[0],p[1])
    }
    return text
}
const patts = [
    [/([a-z]) (\.)( |\s)/ig,"$1\" $3"],
    [/([a-z]) (\")( |\s)/ig,"$1\" $3"],
    [/([A-Za-z])\.(?!([\.\n\r ]|[A-Z]))\b/g,"$1"],
   // [/(Thereafter, )([A-Za-z])/g,(c) => {let m = c[12]
   // return m.toUpperCase()}],
   // [/(thereafter, )/g,","],
   // [/(Thereafter )/g,""],
   // [/(thereafter )/g,""],
    //[/,(\d{3})/g,"$1"],
    [/(\d)\.(\d{3})/g,"$1,$2"],
    [/▶/g, "-->"],
    [/Hmph/g, "Humph"],
    [/PP/g," player points"],
    [/Windsom/g,"Windstorm"],
    [/([^A-z])NG/g, "$1No good"],
    [/hmph/g, "humph"],
    [/\…/g, "..."],
    [/\xA0/g, " "],
    [/Sun\./ig, "Sun ."],
    [/sat\./ig, "sat ."],
    [/([^a-z]*)([Cc])ha([^a-z])/g, "$1$2hah$3"],
    [/([^a-z]*)Ko([^a-z])/g, "$1Koh$2"],
    [/([^a-z]*)Bu([^a-z])/g, "$1Buh$2"],
    [/([^a-z]*)Gu([^a-z])/g, "$1Guh$2"],
    [/([^a-z]*)Min([^a-z])/g, "$1Minh$2"],
    [/([^a-z])da([^a-z])/g, "$1dah$2"],
    [/-Min/g, "min"],
    [/-Il/g, "il"],
    [/-Ho/g, "ho"],
    [/-Ha/g, "ha"],
    [/Mi-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Il-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Min-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Si-[A-Z]/g, (m) => wordPlusLower(m)]
]

function dealWithNoReader(){
    delAll("hr")
    // const a = document.getElementsByTagName("html")
    // a[0].style = "auto"
    let ps = Array.prototype.slice.call(document.getElementsByTagName("p"),0)
    let ls = Array.prototype.slice.call(document.getElementsByTagName("li"),0)
    ps = ps.concat(ls)

    for (let v of ps){
        let e = v.innerText
        if (e == "" ){
            continue
        }else if (!hasReadableLetters(e)){
            console.log(v,v.innerText)
            v.innerText = "[.]"
            continue
        }
        v.innerText = regexDealWith(e,patts)
        if (e == "Only"){
            v.remove()
            continue
        }
        else if (e.includes("velpub") || e.includes("ʟɪɢʜᴛɴᴏᴠᴇʟᴘᴜʙ")){
            console.log("--bad.velpub--",e)
            v.remove()
            continue
        }
    }}

function autonext(text,tries=2){
    var chechPrev_Chapter = window.setInterval(function(){
        var t
        try{
            t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
            if (tries>0){
                tries-=1
                dealWithNoReader()
            }
            if ( t.includes(text) ) {
                document.getElementsByClassName("nextchap")[0].click()
            }
        }//
        catch{tries=2}

    },100)}

(function() {
    'use strict';
    autonext("PREV")
    // setInterval(() => {
        // var t
        // try{
        //     t = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
        //     if (tries>0){
        //         tries-=1
        //         dealWithNoReader()
        //     }
        //     if ( t.includes(text) ) {
        //         document.getElementsByClassName("nextchap")[0].click()
        //     }
        // }//
        // catch{tries=2}

    // },1000)
})();



const badLines = [
    ["MtNovel",],
    ["light‍novel‍pub‍.com",],
    ["Stay tuned on", "for upcoming chapter updates."],
    ["platform to have a great reading experience and follow new episodes."],
    ["keep up with new chapters of this novel"],
    ["Follow the updated", "chapters of the novels"]
]
var c = 0
function badLineInLine(v){

    let e_big = v.innerHTML.split(".")
    console.log(e_big)
    for (let e of e_big){
        console.log(c,"---",e)
        let inclMap = badLines.map(x => x.map(y=>e.includes(y)))
        const bl = inclMap.some(x => x.every(y => y===true))
        if (bl){
            console.log(e)
            e.remove()
        }
}}

function badLine(v){
    c+=1
    let e = v.innerHTML
    let inclMap = badLines.map(x => x.map(y=>e.includes(y)))
    const bl = inclMap.some(x => x.every(y => y===true))
    if (bl){
        console.log(e)
        v.remove()
        return true
    }
    return false
}
function dealWithThereafter(text){
    let uppTAc = /(Thereafter, )([a-z])/g
    let uppTA = /(Thereafter )/g
    let lowTAc = /(thereafter, )/g
    let lowTA = /(thereafter )/g
    return text.replaceAll(lowTAc,",").replaceAll(lowTA,"").replaceAll(uppTAc,(c) => {
        let m = c[12]
        return m.toUpperCase()
    }).replaceAll(uppTA,"")
}

function dealWithMiddleDots(text){
    let reMidDot = /([A-Za-z])\.(?!([\.\n\r ]|[A-Z]))\b/g
    return text.replaceAll(reMidDot,"$1")

}

function dealWithExtraSpace(text){
    let reDot = /([a-z]) (\.)( |\s)/ig;
    let reSlash = /([a-z]) (\")( |\s)/ig;

    return text.replaceAll(reDot,"$1\" $3").replaceAll(reSlash,"$1\" $3")
}