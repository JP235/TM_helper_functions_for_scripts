// ==UserScript==
// @name         dn
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// @match        https://www.webnovelpub.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=webnovelpub.com
// @grant        none
// ==/UserScript==
/* globals jQuery, $,
*/
(function() {
    'use strict';
    $(".chapter-content p > strong > strong, .chapter-content strong i i, .chapter-content p > sub, .chapter-content div > dl").css({'display':'none'})
    // Your code here...
})();