// ==UserScript==
// @name         Auto Next isekailunatic
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://isekailunatic.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=isekailunatic.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    const content = document.getElementsByClassName("entry-content")[0]
    const ps = content.querySelectorAll('p')
    const next = ps[ps.length-1].children[0]
    var chechPrev_Chapter = window.setInterval(() => {
        try{
            let highlightedtext = document.getElementsByClassName("msreadout-line-highlight")[0].innerText
            // console.log(highlightedtext)
            if (
                highlightedtext == "Prev Chapter" ||
                highlightedtext == "Next Chapter"
            ){
                next.click()
                clearInterval(chechPrev_Chapter)
            }
        }
        catch{}

    },100)
    })();