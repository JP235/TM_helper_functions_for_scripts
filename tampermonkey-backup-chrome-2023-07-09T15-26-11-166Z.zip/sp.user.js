// ==UserScript==
// @name         sp
// @namespace    http://tampermonkey.net/
// @description  vid button
// @version      0.1
// @author       You
// @match        https://sxyprn.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var bton0 = document.createElement("button");
    bton0.setAttribute("onclick", "window.location.href='"+document.getElementById("player_el").src+"';");
    bton0.innerText = "Go to video"

    document.getElementsByClassName("pes_author_div")[0].prepend(bton0)
    // Your code here...
})();

// function makeButton() {

//     bton0.style.width = "45px";
//     bton0.style.marginRight = "5px";

//     var spanText = document.createElement("span");
//     spanText.setAttribute("class", "hidden-xs");
//     // spanText.innerHTML = "ON"

//     bton0.appendChild(spanText);
//     bton0.appendChild(ssplay);
//     bton0.setAttribute("id", "Toggle auto-next");
//     return bton0;
// }