// ==UserScript==
// @name         Msushi
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mangasushi.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var bdy = document.getElementsByTagName("body")[0]
    //console.log(bdy)
    bdy.removeAttribute("class");
    //console.log("1",bdy)
})();