// ==UserScript==
// @name         patterns
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://readnovelfull.com/*
// @match        https://allnovelfull.com/*
// @match        https://novelfull.com/*
// @match        https://novelusb.com/*
// @match        https://freewebnovel.com/*
// @match        https://readnovelfull.me/*
// @match        https://isekailunatic.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=novelusb.com

// @require      file://C:\\Users\\jpman\\Documents\\Code\\TM_scripts\\auto_next_.js
// ==/UserScript==
/* globals jQuery, $,
REPL,
getDocHeight,
delAll,
dealWithNoReader,
makeButton,
ssplay,
sspause,
changeSpanText,
wordPlusLower,
hasReadableLetters
*/
// @grant        none
// ==/UserScript==
var patternsRegex = [
    //  [/ /ig," "],
    makePattern("Ukfa"),
    makePattern("Su Ya"),
    makePattern("Ira",1),
    makePattern("Rem",2),
    makePattern("Ya"),
    makePattern("ya"),
    makePattern("Gao",2),
    makePattern("Fa"),
    makePattern("En",1),
    makePattern("Ce"),
    makePattern("Ci"),
    makePattern("Na"),
    makePattern("Xi"),
    makePattern("Wa"),
    makePattern("Mi"),
    makePattern("Xu"),
    makePattern("Ke"),
    makePattern("ke"),
    makePattern("Ka"),
    makePattern("ka"),
    makePattern("Ze"),
    makePattern("Di"),
    makePattern("di"),
    makePattern("Da"),
    makePattern("da"),
    makePattern("Gu"),
    [/WM – /g, ""],
    [/Read more chapter at ReadNovelFull/g, ""],
    [/t_s /g, "t's "],
    [/Arianna/g, "Orianna"],
    [/Feysacian/g, "Feysac"],
    [/Feysacians/g, "Feysacs"],
    [/Evemight/g, "Evernight"],
    [/Marie/g, "Maric"],
    [/Shermane/g, "Sherrmane"],
    [/Hvin/g, "Avin"],
    [/Spade Suit on Apple( iOS 13.3)*/g, " of Spades"],
    [/Club Suit on Apple( iOS 13.3)*/g, " of Clubs"],
    [/Diamond Suit on Apple( iOS 13.3)*/g, " of Diamonds"],
    [/Heart Suit on Apple( iOS 13.3)*/g, " of Hearts"],
    [/Ttniks/g, "Tniks"],
    [/evildoers /g, "evil-doers "],
    [/Psy([^a-z])/g, "Psi$1"],
    [/\( NovelFull \)/g, ""],
    [/([Mm])a’am./g, "$1adam "],
    [/END/g, " Endurance"],
    [/STR/g, " Strength"],
    [/DEX/g, " Dexterity"],
    [/INT/g, " Intelligence"],
    [/MYS/g, " Mysterious"],
    [/CHA/g, " Charm"],
    [/LUK/g, " Luck"],
    [/([Cc])r\*p/g, "$1rap"],
    [/([Dd])\*mn/g, "$1amn"],
    [/ a\*\*/g, " ass"],
    [/ \*ss/g, " ass"],
    [/p\*ss/g, "piss"],
    [/\*ss/g, "Ass"],
    [/A\*\*/g, "Ass"],
    [/([Ss])h\*t/g, "$1hit"],
    [/([Dd])ogshit/g, "$1og-shit"],
    [/([Bb])\*tch/g, "$1itch"],
    [/([Bb])\*ll(s)*/g, "$1all$2"],
    [/([Bb])\*stard/g, "$1astard"],
    [/([Ff])\*ck/g, "$1uck"],
    [/([Ff])\**k/g, "$1uck"],
    [/([Ff])u\*k/g, "$1uck"],
    [/Umhp/g, "Umph"],
    [/Type-i/ig, "Type-1"],
    [/Su Su/g, "Susu"],
    [/Xiao Han/g, "Han Xiao"],
    [/Cycy/g, "Cicy"],
    [/([^a-z]*)Wan([^a-z])/g, "$1Wahn$2"],
    [/Sequence o([^a-z])/g, "Sequence 0$1"],
    [/([^a-z]*)Pu([^a-z])/g, "$1Phu$2"],
    [/([^a-z]*)Ge([^a-z])/g, "$1Geh$2"],
    [/([^a-z]*)Kui([^a-z])/g, "$1Kuih$2"],
    [/([^a-z]*)Ba([^a-z])/g, "$1Bah$2"],
    [/([^a-z]*)Ko([^a-z])/g, "$1Koh$2"],
    [/([^a-z]*)Bu([^a-z])/g, "$1Buh$2"],
    [/([^a-z]*)Gu([^a-z])/g, "$1Guh$2"],
    [/([^a-z]*)Min([^a-z])/g, "$1Minh$2"],
    [/([^a-z]*)Cai([^a-z])/g, "$1Caih$2"],
    [/([^a-z]*)Lang([^a-z])/g, "$1Langh$2"],
    [/([^a-z]*)([Pp])ow([^a-z])/g, "$1$2owh$3"],
    [/([^a-z]*)Mi Er([^a-z])/g, "$1Mih Ehr$2"],
    [/([^a-zA-Z]*)IN([^a-zA-Z])/gm, "$1In$2"],
    [/([^a-zA-Z]*)IT([^a-zA-Z])/gm, "$1It$2"],
    [/\(TN:[^\(]*\)/gm, ""],
    [/CTOS/gm, "CTos"],
    [/\([a-z]*\) *$/gim, "\n"],
    [/▶/g, "-->"],
    [/http.*\//gm, ""],
    [/Hmph/g, "Humph"],
    [/BEar/g, "Bear"],
    [/Hm /g, "Hmm "],
    [/([^a-zA-Z]*)Mm([^a-zA-Z])/g, "$1Mmm$2"],
    [/([^a-zA-Z])mm([^a-zA-Z])/g, "$1mmm$2"],
    [/Xixi/g, "Xixih"],
    [/hmph/g, "humph"],
    // [/\…/g, "..."],
    [/\xA0/g, " "],
    [/Sun\./gi, "Sun ."],
    [/Ruyue/gi, "Riue"],
    [/sat\./gi, "sat ."],
    [/([^a-z]*)([Cc])ha([^a-z])/g, "$1$2hah$3"],
    [/KaTalk/g, "KahTalk"],
    [/Arachne/g, "Arachhne"],
    [/([^a-z]*)mentor Mi([^a-z])/g, "$1mentor Mih$2"],
    // [/([^a-z]*)Qing'e([^a-z])/g, "$1Qinge$2"],
    [/-Min/g, "min"],
    [/Cāng/g, "Caeng"],
    [/Cáng/g, "Caang"],
    [/-Il/gi, "il"],
    [/-Ho/g, "ho"],
    [/-Ha/g, "ha"],
    [/([^\*a-z]*)\*([^\*a-z]*)/gm, "$1'$2"],
    [/Mi-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Il-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Min-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Si-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Chah Chah/g, "Chacha"],
    [/Kristi. Langh/g, "Kristi Langh"],
    [/MB. Freeman/g, "Freeman"],
    [/Gleason. Dodge/g, "Gleason Dodge"],
    [/Aikenseth/g, "Aiken"],
];
var patternsIncludes = [
    "broken links, non-standard content",
    "Translator:",
    "Editor:",
    "oxnove",
    "our website is running thanks to our ads",
    "you could also subscribe",
    "AzureOrchid92",
    "Atlas Studios",
    "You’re reading on NovelFull",
]
var patternsStarts = [
    "Translator:",
    "Translated by",
    "Edited by",
]

function makePattern(word,variation){
    let outWord
    let pattStart
    if (!variation){
        outWord = word+"h"
    }else{
        outWord = word.slice(0,-variation)+"h"+word.slice(-variation)
    }
    if (word[0] === word[0].toUpperCase()){
        pattStart = "([^a-zA-Z]*)"
    } else {
        pattStart = "([^a-zA-Z])"
    }
    return [new RegExp(pattStart+word+"([^a-z])" ,"gm"), "$1"+outWord+"$2"]
}

(function() {
    'use strict';

    // Your code here...
})();