// ==UserScript==
// @name         Auto Next wuxiaworld
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Auto Next wuxiaworld
// @author       Aettos
// @match        www.wuxiaworld.com/*
// ==/UserScript==

const REPL = "[.]"
const minusc = [97,122]
const mayusc = [65,90]
const numbers = [48,57]
const chars = [42, //*
               61, //=
               //63, //?
               // 126 //~
               // 8220,8221, // “ ”
              ]

const lonelySpans = ['☜',
                     "[","]","(",")",". [",".]",
                     "“...","...”","‘...","...’","\"...","...\"",
                     "“…","…”","‘…","…’",
                     ".",","," ."," ,",". ",", ",
                     "“","”"," “"," ”","“ ","” ",
                     "'"," '","' ",
                     "‘","’"," ‘"," ’", "‘ ","’ ",
                     ".”",".’",".‘",".'",".\"","\".",
                     "\""," \"","\" ",
                     "—"," —","— ",
                     '!',' !','! ',
                     '?',' ?','? ',
                    ]

const wordPlusLower = (m) => {
    return [m.substring(0,m.length-2),m[m.length-1].toLowerCase()].join('')}

function hasReadableLetters(text){
    if (text == REPL )return true
    if (lonelySpans.includes(text) )return true
    for (let l = 0; l < text.length; l++){
        let cc = text.charCodeAt(l)
        if (cc >= mayusc[0] && cc <= mayusc[1] ||
            cc >= minusc[0] && cc <= minusc[1] ||
            cc >= numbers[0] && cc <= numbers[1] ||
            chars.includes(cc)
           ){
            return true
        }
    }
    return false
}

var patternsRegex = [
    //  [/ /ig," "],
    makePattern("Tepes",3),
    makePattern("Tehpes",1),
    makePattern("Ukfa"),
    makePattern("Su Ya"),
    makePattern("Rem",2),
    makePattern("Ya"),
    makePattern("ya"),
    makePattern("Gao",2),
    makePattern("Fa"),
    makePattern("En",1),
    makePattern("Ce"),
    makePattern("Ci"),
    makePattern("Na"),
    makePattern("Xi"),
    makePattern("Wa"),
    makePattern("Mi"),
    makePattern("Xu"),
    makePattern("Ke"),
    makePattern("ke"),
    makePattern("Ka"),
    makePattern("ka"),
    makePattern("Ze"),
    makePattern("Di"),
    makePattern("di"),
    makePattern("Da"),
    makePattern("da"),
    makePattern("Gu"),
    [/Read more chapter at ReadNovelFull/g, ""],
    [/S.A/g, "SA"],
    [/t_s /g, "t's "],
    [/Arianna/g, "Orianna"],
    [/Feysacian/g, "Feysac"],
    [/Feysacians/g, "Feysacs"],
    [/Evemight/g, "Evernight"],
    [/Shermane/g, "Sherrmane"],
    [/Hvin/g, "Avin"],
    [/Spade Suit on Apple( iOS 13.3)*/g, " of Spades"],
    [/Club Suit on Apple( iOS 13.3)*/g, " of Clubs"],
    [/Diamond Suit on Apple( iOS 13.3)*/g, " of Diamonds"],
    [/Heart Suit on Apple( iOS 13.3)*/g, " of Hearts"],
    [/Ttniks/g, "Tniks"],
    [/evildoers /g, "evil-doers "],
    [/Psy([^a-z])/g, "Psi$1"],
    [/\( NovelFull \)/g, ""],
    [/([Mm])a’am./g, "$1adam "],
    // [/END/g, " Endurance"],
    // [/STR/g, " Strength"],
    // [/DEX/g, " Dexterity"],
    // [/INT/g, " Intelligence"],
    // [/MYS/g, " Mysterious"],
    // [/CHA/g, " Charm"],
    // [/LUK/g, " Luck"],
    [/([Cc])r\*p/g, "$1rap"],
    [/([Dd])\*mn/g, "$1amn"],
    [/ a\*\*/g, " ass"],
    [/ \*ss/g, " ass"],
    [/p\*ss/g, "piss"],
    [/\*ss/g, "Ass"],
    [/A\*\*/g, "Ass"],
    [/([Ss])h\*t/g, "$1hit"],
    [/([Dd])ogshit/g, "$1og-shit"],
    [/([Bb])\*tch/g, "$1itch"],
    [/([Bb])\*ll(s)*/g, "$1all$2"],
    [/([Bb])\*stard/g, "$1astard"],
    [/([Ff])\*ck/g, "$1uck"],
    [/([Ff])\**k/g, "$1uck"],
    [/([Ff])u\*k/g, "$1uck"],
    [/([Ff])\*k/g, "$1uck"],
    [/([Ff])\*ing/g, "$1ucking"],
    [/Umhp/g, "Umph"],
    [/Type-i/ig, "Type-1"],
    [/Su Su/g, "Susu"],
    [/Xiao Han/g, "Han Xiao"],
    [/Cycy/g, "Cicy"],
    [/([^a-z]*)Wan([^a-z])/g, "$1Wahn$2"],
    [/Sequence o([^a-z])/g, "Sequence 0$1"],
    [/([^a-z]*)Pu([^a-z])/g, "$1Phu$2"],
    [/([^a-z]*)Ge([^a-z])/g, "$1Geh$2"],
    [/([^a-z]*)Kui([^a-z])/g, "$1Kuih$2"],
    [/([^a-z]*)Ba([^a-z])/g, "$1Bah$2"],
    [/([^a-z]*)Ko([^a-z])/g, "$1Koh$2"],
    [/([^a-z]*)Bu([^a-z])/g, "$1Buh$2"],
    [/([^a-z]*)Gu([^a-z])/g, "$1Guh$2"],
    [/([^a-z]*)Min([^a-z])/g, "$1Minh$2"],
    [/([^a-z]*)Cai([^a-z])/g, "$1Caih$2"],
    [/([^a-z]*)Lang([^a-z])/g, "$1Langh$2"],
    [/([^a-z]*)([Pp])ow([^a-z])/g, "$1$2owh$3"],
    [/([^a-z]*)Mi Er([^a-z])/g, "$1Mih Ehr$2"],
    [/([^a-zA-Z]*)IN([^a-zA-Z])/gm, "$1In$2"],
    [/([^a-zA-Z]*)IT([^a-zA-Z])/gm, "$1It$2"],
    [/\(TN:[^\(]*\)/gm, ""],
    [/CTOS/gm, "CTos"],
    [/\([a-z]*\) *$/gim, "\n"],
    [/▶/g, "-->"],
    [/http.*\//gm, ""],
    [/Hmph/g, "Humph"],
    [/BEar/g, "Bear"],
    [/Hm /g, "Hmm "],
    [/([^a-zA-Z]*)Mm([^a-zA-Z])/g, "$1Mmm$2"],
    [/([^a-zA-Z])mm([^a-zA-Z])/g, "$1mmm$2"],
    [/Xixi/g, "Xixih"],
    [/hmph/g, "humph"],
    // [/\…/g, "..."],
    [/\xA0/g, " "],
    [/Sun\./gi, "Sun ."],
    [/Ruyue/gi, "Riue"],
    [/sat\./gi, "sat ."],
    [/([^a-z]*)([Cc])ha([^a-z])/g, "$1$2hah$3"],
    [/KaTalk/g, "KahTalk"],
    [/Arachne/g, "Arachhne"],
    [/([^a-z]*)mentor Mi([^a-z])/g, "$1mentor Mih$2"],
    // [/([^a-z]*)Qing'e([^a-z])/g, "$1Qinge$2"],
    [/-Min/g, "min"],
    [/Cāng/g, "Caeng"],
    [/Cáng/g, "Caang"],
    [/-Il/gi, "il"],
    [/-Ho/g, "ho"],
    [/-Ha/g, "ha"],
    [/([^\*a-z])\*([^a-z])/gm, "$1'$2"],
    [/Mi-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Il-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Min-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Si-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Chah Chah/g, "Chacha"],
    [/Kristi. Langh/g, "Kristi Langh"],
    [/MB. Freeman/g, "Freeman"],
    [/Gleason. Dodge/g, "Gleason Dodge"],
    [/Aikenseth/g, "Aiken"],
    [/Keh ong/g, "Keong"],
];

var patterns = patternsRegex.concat([
    //  [/ /ig," "],
    makePattern("Su Ya"),
    makePattern("Rem",2),
    makePattern("Ya"),
    makePattern("ya"),
    makePattern("Gao",2),
    makePattern("Fa"),
    makePattern("En",1),
    makePattern("Ce"),
    makePattern("Ci"),
    makePattern("Xi"),
    makePattern("Wa"),
    makePattern("Mi"),
    makePattern("Xu"),
    makePattern("Ke"),
    makePattern("ke"),
    makePattern("Ka"),
    makePattern("ka"),
    makePattern("Ze"),
    makePattern("Di"),
    makePattern("di"),
    makePattern("Da"),
    makePattern("da"),
    makePattern("Gu"),
    [/Multi-Dimensional Sky Opening Transportation Device/g, "Sky Opening Device"],
    [/Psy([^a-z])/g, "Psi$1"],
    // [/END/g, " Endurance"],
    // [/STR/g, " Strength"],
    // [/DEX/g, " Dexterity"],
    // [/INT/g, " Intelligence"],
    // [/MYS/g, " Mysterious"],
    // [/CHA/g, " Charm"],
    // [/LUK/g, " Luck"],
    [/([Cc])r\*p/g, "$1rap"],
    [/([Dd])\*mn/g, "$1amn"],
    [/ \*ss/g, " ass"],
    [/\*ss/g, "Ass"],
    [/([Ss])h\*t/g, "$1hit"],
    [/([Bb])\*tch/g, "$1itch"],
    [/([Bb])\*ll(s)*/g, "$1all$2"],
    [/([Bb])\*stard/g, "$1astard"],
    [/([Ff])\*ck/g, "$1uck"],
    [/([Ff])u\*k/g, "$1uck"],
    // makePattern("An",1),
    [/Umhp/g, "Umph"],
    [/Type-i/ig, "Type-1"],
    [/Su Su/g, "Susu"],
    [/Xiao Han/g, "Han Xiao"],
    [/Cycy/g, "Cicy"],
    [/([^a-z]*)Wan([^a-z])/g, "$1Wahn$2"],
    [/([^a-z]*)Pu([^a-z])/g, "$1Phu$2"],
    [/([^a-z]*)Ge([^a-z])/g, "$1Geh$2"],
    [/([^a-z]*)Kui([^a-z])/g, "$1Kuih$2"],
    [/([^a-z]*)Ba([^a-z])/g, "$1Bah$2"],
    [/([^a-z]*)Ko([^a-z])/g, "$1Koh$2"],
    [/([^a-z]*)Bu([^a-z])/g, "$1Buh$2"],
    [/([^a-z]*)Gu([^a-z])/g, "$1Guh$2"],
    [/([^a-z]*)Min([^a-z])/g, "$1Minh$2"],
    [/([^a-z]*)Cai([^a-z])/g, "$1Caih$2"],
    [/([^a-z]*)Lang([^a-z])/g, "$1Langh$2"],
    [/([^a-z]*)([Pp])ow([^a-z])/g, "$1$2owh$3"],
    [/([^a-z]*)Mi Er([^a-z])/g, "$1Mih Ehr$2"],
    [/([^a-zA-Z]*)IN([^a-zA-Z])/gm, "$1In$2"],
    [/([^a-zA-Z]*)IT([^a-zA-Z])/gm, "$1It$2"],
    [/\(TN:[^\(]*\)/gm, ""],
    [/CTOS/gm, "CTos"],
    [/\([a-z]*\) *$/gim, "\n"],
    [/▶/g, "-->"],
    [/http.*\//gm, ""],
    [/Hmph/g, "Humph"],
    [/BEar/g, "Bear"],
    [/Hm /g, "Hmm "],
    [/([^a-zA-Z]*)Mm([^a-zA-Z])/g, "$1Mmm$2"],
    [/([^a-zA-Z])mm([^a-zA-Z])/g, "$1mmm$2"],
    [/Xixi/g, "Xixih"],
    [/hmph/g, "humph"],
    [/\…/g, "..."],
    [/\xA0/g, " "],
    [/Sun\./gi, "Sun ."],
    [/Ruyue/gi, "Riue"],
    [/sat\./gi, "sat ."],
    [/([^a-z]*)([Cc])ha([^a-z])/g, "$1$2hah$3"],
    [/KaTalk/g, "KahTalk"],
    [/Arachne/g, "Arachhne"],
    [/([^a-z]*)mentor Mi([^a-z])/g, "$1mentor Mih$2"],
    // [/([^a-z]*)Qing'e([^a-z])/g, "$1Qinge$2"],
    [/-Min/g, "min"],
    [/Cāng/g, "Caeng"],
    [/Cáng/g, "Caang"],
    [/-Il/gi, "il"],
    [/-Ho/g, "ho"],
    [/-Ha/g, "ha"],
    [/([^\*a-z])\*([^a-z])/gm, "$1'$2"],
    [/Mi-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Il-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Min-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Si-[A-Z]/g, (m) => wordPlusLower(m)],
    [/Chah Chah/g, "Chacha"],
    [/Kristi. Langh/g, "Kristi Langh"],
    [/MB. Freeman/g, "Freeman"],
    [/Gleason. Dodge/g, "Gleason Dodge"],
    [/Aikenseth/g, "Aiken"],
]);

function regexDealWith(text){
    for (let p of patterns){
        text = text.replaceAll(p[0],p[1])
    }
    return text
}
function unMultiSpan(){
    let content = document.getElementsByClassName("chapter-content")[0].getElementsByTagName("p")
    console.log("ums")
    for (let ch of content){
        if (ch.className.includes("cursor-pointer")) continue
        // if (ch.childNodes.length>1){
        //     console.log(ch.childNodes.length)
        //     console.log(ch)
        // }
        while (ch.childNodes.length>1 ){
            let txt = ch.childNodes[0].innerText ? ch.childNodes[0].innerText : ch.childNodes[0].data;
            for (let i = 1; i < ch.childNodes.length+1;i++){
                let e = ch.childNodes[1]
                if (e.innerText) {
                    txt = [txt, e.innerText].join("")
                }
                else{
                    txt = [txt, e.data].join("")
                }
                e.remove()
                // console.log(ch.childNodes.length)
            }
            ch.childNodes[0].innerText ? ch.childNodes[0].innerText = txt : ch.childNodes[0].data = txt
        }
    }
}

function dealWithNoReader(){
    console.log("dealWithNoReader")
    const ps = document.getElementsByClassName("chapter-content")[0].getElementsByTagName("p")
    for (let v of ps){
        v.innerText = regexDealWith(v.innerText)
        if (v.children.length == 1 && v.children[0].outerHTML == "<br>") continue
        if (v.children.length == 1 && v.children[0].outerHTML == "<a>") continue
        if (!v.innerText || [""," "].includes(v.innerText)) continue
        if (!hasReadableLetters(v.innerText)){
            console.log(v,v.innerText)
            v.innerText = REPL
            console.log(v.innerText)
        }
    }
}
function checkMSReader(){
    var n=1
    var chech = window.setInterval(() => {
        let highlight = document.getElementsByClassName("msreadout-line-highlight")[0]
        try {
            let t = highlight.innerText
            if (n > 0) {
                unMultiSpan()
                dealWithNoReader()
                n -= 1
            }
            if (t === "Favorite" || t.includes("Chapter marked as read!") || t.includes("NEXT CHAPTER") || t.includes("rainbowturtle")|| t.includes("Midasthefloof") || t.includes("Jaspaaar")) next_it()
        }
        catch {
            n = 1
        }
    },50)
    }

function next_it(){
    const link = [...document.getElementsByTagName("a")].find(a => a.innerText.includes("NEXT"));
    console.log("Going next");
    console.log(link);
    window.location.href = link.href;
    return false
}
function makePattern(word,variation){
    let outWord
    let pattStart
    if (!variation){
        outWord = word+"h"
    }else{
        outWord = word.slice(0,-variation)+"h"+word.slice(-variation)
    }
    if (word[0] === word[0].toUpperCase()){
        pattStart = "([^a-zA-Z]*)"
    } else {
        pattStart = "([^a-zA-Z])"
    }
    return [new RegExp(pattStart+word+"([^a-z])" ,"gm"), "$1"+outWord+"$2"]
}
(function() {
    'use strict';
    const a = document.getElementsByClassName("py-12 md:pb-0")
    console.log(a)
    setTimeout(function(){
        a[0].remove()
        console.log(a)
    }, 2000);

    checkMSReader();
})();














